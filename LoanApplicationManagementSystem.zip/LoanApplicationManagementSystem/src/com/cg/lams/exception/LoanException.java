package com.cg.lams.exception;

public class LoanException extends Exception 
{
	public LoanException(String msg)
	{
		super(msg);
	}
}
